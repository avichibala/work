export class Course {
  id: number;
  name: string;
  duration: number;
  description: string;
  technology: string;
  launchUrl: string;
}
