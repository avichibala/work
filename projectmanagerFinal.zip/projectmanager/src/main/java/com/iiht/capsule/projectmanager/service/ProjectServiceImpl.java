package com.iiht.capsule.projectmanager.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.capsule.projectmanager.model.Project;
import com.iiht.capsule.projectmanager.repo.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;

	@Override
	public Project addProject(Project project) {
		return projectRepository.save(project);
	}

	@Override
	public List<Project> getAllProjects() {
		List<Project> Projects = new ArrayList<>();
		projectRepository.findAll().forEach(Projects::add);
		return Projects;
	}

	@Override
	public Project updateProject(Project project, Long Id) {
		Project ProjectAvailable = projectRepository.findById(Id).orElse(null);
		if (ProjectAvailable != null) {
			project.setProjectId(Id);
			projectRepository.save(project);
		}
		return ProjectAvailable;

	}

	@Override
	public Project getProject(Long Id) {
		Project ProjectAvailable = projectRepository.findById(Id).orElse(null);
		return ProjectAvailable;
	}

	@Override
	public void deleteProject(Long Id) {

		projectRepository.deleteById(Id);

	}

}
