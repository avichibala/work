package com.iiht.capsule.lms.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserRequest {

	@NotEmpty(message = "User name must not be empty")
	private String name;

	@NotEmpty(message = "User email must not be empty")
	@Email(message = "User email should be a valid email")
	private String emailId;

	@NotEmpty(message = "Password must not be empty")
	@Size(min = 8, message = "Password should be Alphanumeric and at least 8 characters")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Password should be Alphanumeric and at least 8 characters")
	private String password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "UserRequest [name=" + name + ", emailId=" + emailId + ", password=" + password + "]";
	}

}
