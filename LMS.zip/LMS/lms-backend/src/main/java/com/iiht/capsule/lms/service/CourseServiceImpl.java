package com.iiht.capsule.lms.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.capsule.lms.entity.Course;
import com.iiht.capsule.lms.model.CourseRequest;
import com.iiht.capsule.lms.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;

	@Override
	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	@Override
	public Course getCourseByName(String coursename) {
		Course course = courseRepository.findByName(coursename).orElse(null);
		return course;
	}

	@Override
	public List<Course> getCourseByTechnology(String technology) {
		return courseRepository.findByTechnology(technology);
	}

	@Override
	public List<Course> getCourseByDuration(String technology, int durationFromRange, int durationToRange) {
		List<Course> technologyCourses = getCourseByTechnology(technology);
		List<Course> techCourses = technologyCourses.stream()
				.filter(course -> course.getDuration() >= durationFromRange && course.getDuration() <= durationToRange)
				.collect(Collectors.toList());
		return techCourses;
	}

	@Override
	public void deleteCourse(int id) {
		courseRepository.deleteById(id);

	}

	@Override
	public Course addCourse(CourseRequest courseRequest) {
		if (courseRequest.getDuration() == 0) {
			return null;
		}
		Course course = new Course();
		course.setId(generateUserId());
		course.setDescription(courseRequest.getDescription());
		course.setDuration((int) courseRequest.getDuration());
		course.setName(courseRequest.getName());
		course.setTechnology(courseRequest.getTechnology());
		course.setLaunchUrl(courseRequest.getLaunchUrl());
		return courseRepository.save(course);
	}

	private int generateUserId() {
		int min = 1;
		int max = 1000;
		return (int) (Math.random() * (max - min + 1) + min);
	}

}
