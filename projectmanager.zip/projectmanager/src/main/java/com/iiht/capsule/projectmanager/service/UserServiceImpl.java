package com.iiht.capsule.projectmanager.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.capsule.projectmanager.model.User;
import com.iiht.capsule.projectmanager.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public User addUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		List<User> Users = new ArrayList<>();
		userRepository.findAll().forEach(Users::add);
		return Users;
	}

	@Override
	public User updateUser(User user, Long Id) {
		User UserAvailable = userRepository.findById(Id).orElse(null);
		user.setUserId(Id);
		userRepository.save(user);
		return UserAvailable;
	}

	@Override
	public User getUser(Long Id) {
		User UserAvailable = userRepository.findById(Id).orElse(null);
		return UserAvailable;
	}

	@Override
	public void deleteUser(Long Id) {

		userRepository.deleteById(Id);

	}

}
