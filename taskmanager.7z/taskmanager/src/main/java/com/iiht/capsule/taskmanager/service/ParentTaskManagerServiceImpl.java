package com.iiht.capsule.taskmanager.service;

public class ParentTaskManagerServiceImpl implements ParentTaskManagerService {

}
