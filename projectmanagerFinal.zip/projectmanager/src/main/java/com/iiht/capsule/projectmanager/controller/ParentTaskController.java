package com.iiht.capsule.projectmanager.controller;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.iiht.capsule.projectmanager.model.ParentTask;
import com.iiht.capsule.projectmanager.service.ParentTaskService;

@RestController
public class ParentTaskController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ParentTaskController.class);

	@Autowired
	private ParentTaskService parentTaskService;

	@RequestMapping("/helloParentTask")
	public String ParentTasks() {
		return "Hello ParentTask";
	}

	@RequestMapping("/parenttasks")
	public List<ParentTask> getAllParentTasks() {
		return parentTaskService.getAllParentTasks();
	}

	@RequestMapping("/parenttasks/{id}")
	public ResponseEntity<Object> getParentTask(@PathVariable long id) {
		LOGGER.info("**********ID***********" + id);
		ParentTask updatedParentTask = parentTaskService.getParentTask(id);

		if (updatedParentTask != null) {
			return ResponseEntity.ok(updatedParentTask);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ParentTask not found with ID " + id);

	}

	@PostMapping("/parenttasks")
	public ResponseEntity<Object> createParentTask(@RequestBody ParentTask parentTask) {
		LOGGER.info("********************" + parentTask.toString());
		ParentTask createdParentTask = parentTaskService.addParentTask(parentTask);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(createdParentTask.getId()).toUri();

		return ResponseEntity.created(location).build();

	}

	@PutMapping("/parenttasks/{id}")
	public ResponseEntity<Object> updateParentTask(@RequestBody ParentTask parentTask, @PathVariable Long id) {
		LOGGER.info("*********ParentTask***********" + parentTask.toString());
		LOGGER.info("**********ID***********" + id);
		ParentTask updatedParentTask = parentTaskService.updateParentTask(parentTask, id);

		if (updatedParentTask != null) {
			return ResponseEntity.status(HttpStatus.OK).body("ParentTask updated successfully with ID " + id);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ParentTask not found with ID " + id);

	}

	@DeleteMapping("/parenttasks/{id}")
	public ResponseEntity<Object> deleteParentTask(@PathVariable Long id) {
		LOGGER.info("**********ID***********" + id);
		ParentTask ParentTask = parentTaskService.getParentTask(id);

		if (ParentTask != null) {
			parentTaskService.deleteParentTask(id);

			return ResponseEntity.status(HttpStatus.OK).body("ParentTask deleted successfully with ID " + id);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ParentTask not found with ID " + id);

	}

}
