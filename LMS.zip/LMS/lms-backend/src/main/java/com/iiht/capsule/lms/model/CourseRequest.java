package com.iiht.capsule.lms.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CourseRequest {

	@NotNull(message = "Course name must not be empty")
	@Size(min = 20, message = "Course Name should be of minimum 20 characters")
	private String name;
	@NotNull(message = "Duration must not be null")
	private Integer duration;
	@NotNull(message = "Course Description must not be null")
	@Size(min = 100, message = "Course Description should be of minimum 100 characters")
	private String description;
	@NotEmpty(message = "Technology must not be empty")
	private String technology;
	@NotEmpty(message = "LaunchUrl must not be empty")
	private String launchUrl;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getLaunchUrl() {
		return launchUrl;
	}

	public void setLaunchUrl(String launchUrl) {
		this.launchUrl = launchUrl;
	}

	@Override
	public String toString() {
		return "CourseRequest [name=" + name + ", duration=" + duration + ", description=" + description
				+ ", technology=" + technology + ", launchUrl=" + launchUrl + "]";
	}

}
