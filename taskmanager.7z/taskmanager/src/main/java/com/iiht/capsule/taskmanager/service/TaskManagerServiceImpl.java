package com.iiht.capsule.taskmanager.service;

public class TaskManagerServiceImpl implements TaskManagerService {

}
