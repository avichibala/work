import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { UserService } from "../service/user.service";
import { User } from "../models/user.model";
import { FormGroup, FormBuilder } from '@angular/forms';
import { taskDataService } from "../service/datastorage.service";
import { ModalDirective } from "angular-bootstrap-md";

@Component({
  selector: "app-user",
  templateUrl: "./user.component.html",
  styleUrls: ["./user.component.scss"]
})
export class UserComponent implements OnInit {
  @ViewChild('closeBtn') closeBtn: ElementRef;
  @ViewChild('frame') frame: ModalDirective;

  userForm: FormGroup;
  data;
  filterData;
  userData: User;
  isSubmitDisabled = false;
  isUpdateDisabled = true;
  title = "Add";
  constructor(
    private http: HttpClient,
    private userService: UserService,
    private formBuilder: FormBuilder,
    private dataStore: taskDataService) {
    this.userForm = this.createFormGroup(formBuilder);
  }

  ngOnInit() {
    this.getData();
  }

  addUserData() {
    this.userForm = this.createFormGroup(this.formBuilder);
    this.isSubmitDisabled = false;
    this.isUpdateDisabled = true;
    this.title = "Add";
  }

  updateUserData(user: User) {
    this.userForm = this.createEditFormGroup(this.formBuilder, user);
    this.isSubmitDisabled = true;
    this.isUpdateDisabled = false;
    this.title = "Update";
  }

  createFormGroup(formBuilder: FormBuilder) {
    return formBuilder.group({
      firstName: '',
      lastName: '',
      employeeId: ''
    });
  }

  createEditFormGroup(formBuilder: FormBuilder, user: User) {
    return formBuilder.group({
      userId: user.userId,
      firstName: user.firstName,
      lastName: user.lastName,
      employeeId: user.employeeId
    });
  }

  revert() {
    // Resets to blank object
    // Resets to provided model

    if (this.title == "Add") { this.userForm = this.createFormGroup(this.formBuilder); }
    else {
      this.userForm.patchValue({
        firstName: '',
        lastName: '',
        employeeId: ''
      });
    }
  }

  onSubmit() {
    // Make sure to create a deep copy of the form-model
    const user: User = Object.assign({}, this.userForm.value);

    // Do useful stuff with the gathered data
    console.log(user);
    this.userService.createUser(user).subscribe(data => {
      console.log(user);
      this.ngOnInit();
    });
    this.revert();
    this.closeBtn.nativeElement.click();
    this.frame.hide();
  }

  updateUser() {
    const user: User = Object.assign({}, this.userForm.value);

    // Do useful stuff with the gathered data
    console.log("Update User");
    console.log(user);
    this.userService.updateUser(user).subscribe(data => {
      this.getData();
    });
    this.frame.hide();
  }


  deleteUser(user: User): void {
    this.userService.deleteUser(user).subscribe(

      data => {
        this.getData();
      }
    );
  }

  getData(): void {
    this.userService.getUser().subscribe(res => {
      this.data = res;
      this.filterData = res;
    },
      err => { console.log("Error occured"); }
    );

    console.log("Get Data" + JSON.stringify(this.filterData));
  }

  search(term: string) {
    if (!term) {
      this.filterData = this.data;
      console.log("Filter Data before Search" + JSON.stringify(this.filterData));
    } else {
      this.filterData = this.data.filter(
        x =>
          x.firstName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.lastName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.employeeId
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase())
      );
      console.log("Filter Data after Search" + JSON.stringify(this.filterData));
    }
  }
}
