package com.iiht.capsule.projectmanager.controller;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.iiht.capsule.projectmanager.model.Project;
import com.iiht.capsule.projectmanager.service.ProjectService;

@RestController
public class ProjectController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectController.class);

	@Autowired
	private ProjectService projectService;

	@RequestMapping("/helloProject")
	public String Projects() {
		return "Hello Project";
	}

	@RequestMapping("/projects")
	public List<Project> getAllProjects() {
		return projectService.getAllProjects();
	}

	@RequestMapping("/projects/{id}")
	public ResponseEntity<Object> getProject(@PathVariable long id) {
		LOGGER.info("**********ID***********" + id);
		Project updatedProject = projectService.getProject(id);

		if (updatedProject != null) {
			return ResponseEntity.ok(updatedProject);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found with ID " + id);

	}

	@PostMapping("/projects")
	public ResponseEntity<Object> createProject(@RequestBody Project project) {
		LOGGER.info("********************" + project.toString());
		Project createdProject = projectService.addProject(project);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(createdProject.getProjectId()).toUri();

		return ResponseEntity.created(location).build();

	}

	@PutMapping("/projects/{id}")
	public ResponseEntity<Object> updateProject(@RequestBody Project project, @PathVariable Long id) {
		LOGGER.info("*********Project***********" + project.toString());
		LOGGER.info("**********ID***********" + id);
		Project updatedProject = projectService.updateProject(project, id);

		if (updatedProject != null) {
			return ResponseEntity.status(HttpStatus.OK).body("Project updated successfully with ID " + id);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found with ID " + id);

	}

	@DeleteMapping("/projects/{id}")
	public ResponseEntity<Object> deleteProject(@PathVariable Long id) {
		LOGGER.info("**********ID***********" + id);
		Project Project = projectService.getProject(id);

		if (Project != null) {
			projectService.deleteProject(id);

			return ResponseEntity.status(HttpStatus.OK).body("Project deleted successfully with ID " + id);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found with ID " + id);

	}

}
