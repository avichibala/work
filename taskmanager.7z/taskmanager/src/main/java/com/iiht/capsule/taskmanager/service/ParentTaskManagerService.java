package com.iiht.capsule.taskmanager.service;

public interface ParentTaskManagerService {

}
