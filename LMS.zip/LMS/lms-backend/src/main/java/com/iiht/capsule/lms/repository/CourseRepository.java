package com.iiht.capsule.lms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.iiht.capsule.lms.entity.Course;

public interface CourseRepository extends MongoRepository<Course, Integer> {

	Optional<Course> findByName(String coursename);

	List<Course> findByTechnology(String technology);
}