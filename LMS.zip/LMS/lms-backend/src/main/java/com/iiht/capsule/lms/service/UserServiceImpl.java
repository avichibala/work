package com.iiht.capsule.lms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.capsule.lms.entity.User;
import com.iiht.capsule.lms.model.UserRequest;
import com.iiht.capsule.lms.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	public User addUser(UserRequest userRequest) {
		User user = new User();
		user.setId(generateUserId());
		user.setEmailId(userRequest.getEmailId());
		user.setName(userRequest.getName());
		user.setPassword(userRequest.getPassword());
		return userRepository.save(user);
	}

	private int generateUserId() {
		int min = 1;
		int max = 1000;
		return (int) (Math.random() * (max - min + 1) + min);
	}

}
