import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ProjectService } from "../service/project.service";
import { UserService } from "../service/user.service";
import { Project } from "../models/project.model";
import { FormGroup, FormBuilder } from '@angular/forms';
import { ModalDirective } from "angular-bootstrap-md";
import { DatePipe } from '@angular/common';
import { User } from "../models/user.model";
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent implements OnInit {
  @ViewChild('closeBtn') closeBtn: ElementRef;
  @ViewChild('frame') frame: ModalDirective;

  projectForm: FormGroup;
  data;
  filterData;
  userData;
  selectedPriority: number;
  isSubmitDisabled = false;
  isUpdateDisabled = true;
  title = "Add";
  managerPlaceholder = "Select Manager";
  public formStartDate: Date;
  public formEndDate: Date;

  constructor(
    private http: HttpClient,
    private projectService: ProjectService,
    private userService: UserService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe) {
    this.projectForm = this.createFormGroup(formBuilder);
  }

  createFormGroup(formBuilder: FormBuilder) {
    console.log(this.selectedPriority);
    this.formStartDate;
    this.formEndDate;
    this.selectedPriority = 0;
    this.managerPlaceholder = "Select Manager";
    return formBuilder.group({
      projectName: '',
      startDate: '',
      endDate: '',
      priority: '',
      manager: ({
        userId: ''
      })
    });
  }

  ngOnInit() {
    this.getData();
    this.getUserData();
  }

  onUserChange(user: User) {
    console.log(user);
  }
  addProjectData() {
    this.projectForm = this.createFormGroup(this.formBuilder);
    this.isSubmitDisabled = false;
    this.isUpdateDisabled = true;
    this.title = "Add";
    this.revert();
  }

  updateProjectData(project: Project) {
    this.projectForm = this.createEditFormGroup(this.formBuilder, project);
    this.isSubmitDisabled = true;
    this.isUpdateDisabled = false;
    this.title = "Update";
  }

  createEditFormGroup(formBuilder: FormBuilder, project: Project) {

    this.formStartDate = project.startDate;
    this.formEndDate = project.endDate;
    this.selectedPriority = project.priority;
    this.managerPlaceholder = project.manager.firstName;
    return formBuilder.group({
      projectId: project.projectId,
      projectName: project.projectName,
      startDate: project.startDate,
      endDate: project.endDate,
      priority: project.priority,
      manager: formBuilder.group({
        userId: project.manager.userId
      })
    });
  }

  revert() {
    // Resets to blank object
    // Resets to provided model

    if (this.title == "Add") {
      this.projectForm = this.createFormGroup(this.formBuilder);
      this.formStartDate;
      this.formEndDate;
      this.selectedPriority = 0;

    }
    else {
      this.formStartDate;
      this.formEndDate;
      this.selectedPriority = 0;
      this.projectForm.patchValue({
        projectName: '',
        startDate: '',
        endDate: '',
        priority: '',
        manager: ({
          userId: ''
        })
      });
    }
  }

  getData(): void {
    this.projectService.getProject().subscribe(res => {
      this.data = res;
      this.filterData = res;
    },
      err => { console.log("Error occured"); }
    );

    console.log("Get Data" + JSON.stringify(this.filterData));
  }


  getUserData(): void {
    this.userService.getUser().subscribe(res => {
      this.userData = res;
    },
      err => { console.log("Error occured"); }
    );

    console.log("Get Data" + JSON.stringify(this.userData));
  }

  getFormatdate(changeDate: Date): any {
    return this.datePipe.transform(changeDate, "yyyy-MM-dd");
  }

  updateProject() {
    const project: Project = Object.assign({}, this.projectForm.value);

    // Do useful stuff with the gathered data
    console.log("Update Project");
    console.log(project);
    this.projectService.updateProject(project).subscribe(data => {
      this.getData();
    });
    this.frame.hide();
    this.revert();
  }


  deleteProject(project: Project): void {
    this.projectService.deleteProject(project).subscribe(

      data => {
        this.getData();
      }
    );
  }

  onSubmit() {
    const projectData: Project = Object.assign({}, this.projectForm.value);
    // Do useful stuff with the gathered data
    console.log(projectData);

    this.projectService.createProject(projectData).subscribe(data => {
      console.log(projectData);
      this.ngOnInit();
    });
    this.closeBtn.nativeElement.click();
    this.frame.hide();
    this.revert();
  }


  changeValue(e) {
    console.log(e.newValue);
    this.selectedPriority = e.newValue;
    this.projectForm.patchValue({
      priority: this.selectedPriority
    });
  }
  getUserValue(e) {
    console.log(e);
    this.projectForm.patchValue({
      manager: ({
        userId: e.userId
      })
    });
  }
  changeStartDate(e) {
    console.log(e.value);
    var start = this.getFormatdate(e.value);
    this.projectForm.patchValue({
      startDate: start
    });
  }

  changeEndDate(e) {
    console.log(e.value);
    var end = this.getFormatdate(e.value);
    this.projectForm.patchValue({
      endDate: end
    });
  }
  search(term: string) {
    if (!term) {
      this.filterData = this.data;
      console.log("Filter Data before Search" + JSON.stringify(this.filterData));
    } else {
      this.filterData = this.data.filter(
        x =>
          x.projectName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.numberofTasks.toString()
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.completedTasks.toString()
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.manager.firstName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.manager.lastName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.startDate
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.endDate
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.priority.toString()
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase())
      );
      console.log("Filter Data after Search" + JSON.stringify(this.filterData));
    }
  }

  endProject(project: Project): void {
    console.log("end");
    project.isCompleted = true;
    console.log(project);
    this.projectService.updateEndProject(project).subscribe(data => {
      console.log(project.projectName + " has been ended");
    },
      err => { console.log("Error occured"); }
    );
  }
}
