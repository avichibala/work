package com.iiht.capsule.lms.service;

import com.iiht.capsule.lms.entity.User;
import com.iiht.capsule.lms.model.UserRequest;

public interface UserService {

	public User addUser(UserRequest userRequest);

}
