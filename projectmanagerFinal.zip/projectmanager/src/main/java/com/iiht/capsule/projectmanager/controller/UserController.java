package com.iiht.capsule.projectmanager.controller;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.iiht.capsule.projectmanager.model.User;
import com.iiht.capsule.projectmanager.service.UserService;

@RestController
public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@RequestMapping("/helloUser")
	public String Users() {
		return "Hello User";
	}

	@RequestMapping("/users")
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}

	@RequestMapping("/users/{id}")
	public ResponseEntity<Object> getUser(@PathVariable long id) {
		LOGGER.info("**********ID***********" + id);
		User updatedUser = userService.getUser(id);

		if (updatedUser != null) {
			return ResponseEntity.ok(updatedUser);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID " + id);

	}

	@PostMapping("/users")
	public ResponseEntity<Object> createUser(@RequestBody User user) {
		LOGGER.info("********************" + user.toString());
		User createdUser = userService.addUser(user);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(createdUser.getUserId()).toUri();

		return ResponseEntity.created(location).build();

	}

	@PutMapping("/users/{id}")
	public ResponseEntity<Object> updateUser(@RequestBody User user, @PathVariable Long id) {
		LOGGER.info("*********User***********" + user.toString());
		LOGGER.info("**********ID***********" + id);
		User updatedUser = userService.updateUser(user, id);

		if (updatedUser != null) {
			return ResponseEntity.status(HttpStatus.OK).body("User updated successfully with ID " + id);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID " + id);

	}

	@DeleteMapping("/users/{id}")
	public ResponseEntity<Object> deleteUser(@PathVariable Long id) {
		LOGGER.info("**********ID***********" + id);
		User User = userService.getUser(id);

		if (User != null) {
			userService.deleteUser(id);

			return ResponseEntity.status(HttpStatus.OK).body("User deleted successfully with ID " + id);
		}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID " + id);

	}

}
