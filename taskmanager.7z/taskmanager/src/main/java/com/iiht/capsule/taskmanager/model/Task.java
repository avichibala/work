package com.iiht.capsule.taskmanager.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "task")
@Table(name = "task")
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;

	@ManyToOne
	private ParentTask parentTask;

	private String name;

	private String task;

	private String startDate;

	private String endDate;

	private String priority;

	public String getEndDate() {
		return endDate;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public ParentTask getParentTask() {
		return parentTask;
	}

	public String getPriority() {
		return priority;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getTask() {
		return task;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setParentTask(ParentTask parentTask) {
		this.parentTask = parentTask;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setTask(String task) {
		this.task = task;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", parentTask=" + parentTask + ", name=" + name + ", task=" + task + ", startDate="
				+ startDate + ", endDate=" + endDate + ", priority=" + priority + "]";
	}
}
