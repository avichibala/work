package com.iiht.capsule.taskmanager.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TaskManagerController {
	final static Logger logger = Logger.getLogger(TaskManagerController.class);

	@RequestMapping("/hello")
	public String Tasks() {
		return "Hello";
	}
}
