package com.iiht.capsule.lms.service;

import java.util.List;

import com.iiht.capsule.lms.entity.Course;
import com.iiht.capsule.lms.model.CourseRequest;

public interface CourseService {

	List<Course> getAllCourses();

	Course getCourseByName(String coursename);

	List<Course> getCourseByTechnology(String technology);

	List<Course> getCourseByDuration(String technology, int durationFromRange, int durationToRange);

	void deleteCourse(int id);

	Course addCourse(CourseRequest courseRequest);
	
}
