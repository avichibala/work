package com.iiht.capsule.projectmanager.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iiht.capsule.projectmanager.model.ParentTask;
import com.iiht.capsule.projectmanager.model.Project;
import com.iiht.capsule.projectmanager.model.Task;
import com.iiht.capsule.projectmanager.model.User;
import com.iiht.capsule.projectmanager.service.ProjectService;
import com.iiht.capsule.projectmanager.service.TaskService;
import com.iiht.capsule.projectmanager.service.UserService;

@RunWith(SpringRunner.class)
@ContextConfiguration({ "classpath*:spring-test.xml" })
public class TaskControllerTest {

	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@Mock
	private TaskService taskService;

	@Mock
	private UserService userService;

	@Mock
	private ProjectService projectService;

	private MockMvc mockMvc;

	private Task task1 = new Task();

	private Task task2 = new Task();

	private Project project = new Project();

	private User user = new User();

	@InjectMocks
	private TaskController taskController;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(taskController).build();
		getTaskTestData();
	}

	@Test
	public void getAllTasks() throws IOException, ParseException, Exception {

		List<Task> tasks = new ArrayList<Task>();
		tasks.add(task1);
		tasks.add(task2);

		when(taskService.getAllTasks()).thenReturn(tasks);
		mockMvc.perform(get("/tasks")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$[0].taskId", is(1))).andExpect(jsonPath("$[0].startDate", is(notNullValue())))
				.andExpect(jsonPath("$[0].endDate", is(notNullValue()))).andExpect(jsonPath("$[0].priority", is(20)))
				.andExpect(jsonPath("$[0].isCompleted", is(false)))
				.andExpect(jsonPath("$[0].parentTask.parentTaskName", is("Parent_Task")))
				.andExpect(jsonPath("$[0].user.userId", is(1))).andExpect(jsonPath("$[0].project.projectId", is(1)))
				.andExpect(jsonPath("$[0].task", is("Task_1"))).andExpect(jsonPath("$[1].taskId", is(2)))
				.andExpect(jsonPath("$[1].startDate", is(notNullValue())))
				.andExpect(jsonPath("$[1].endDate", is(notNullValue()))).andExpect(jsonPath("$[1].priority", is(10)))
				.andExpect(jsonPath("$[1].isCompleted", is(true)))
				.andExpect(jsonPath("$[1].parentTask.parentTaskName", is("Parent_Task")))
				.andExpect(jsonPath("$[1].user.userId", is(1))).andExpect(jsonPath("$[1].project.projectId", is(1)))
				.andExpect(jsonPath("$[1].task", is("Task_2"))).andDo(print());
		verify(taskService, times(1)).getAllTasks();
		verifyNoMoreInteractions(taskService);
	}

	public void getTaskTestData() {

		ParentTask pt = new ParentTask();
		pt.setId(1);
		pt.setParentTaskName("Parent_Task");
		System.out.print("******************************Test Started******************************");
		LocalDate startdate1 = LocalDate.of(2017, 1, 13);
		LocalDate startdate2 = LocalDate.of(2017, 2, 13);
		LocalDate enddate1 = LocalDate.of(2017, 3, 13);
		LocalDate enddate2 = LocalDate.of(2017, 4, 13);
		user.setEmployeeId("1");
		user.setFirstName("FN");
		user.setLastName("LN");
		user.setUserId(1);
		project.setCompletedTasks(10);
		project.setEndDate(enddate1);
		project.setIsCompleted(false);
		project.setManager(user);
		project.setNumberofTasks(20);
		project.setPriority(10);
		project.setProjectId(1);
		project.setProjectName("Project_1");
		project.setStartDate(startdate1);

		task1.setStartDate(startdate1);
		task1.setEndDate(enddate1);
		task1.setParentTask(pt);
		task1.setIsCompleted(false);
		task1.setPriority(20);
		task1.setTask("Task_1");
		task1.setTaskId(1);
		task1.setProject(project);
		task1.setUser(user);

		task2.setStartDate(startdate2);
		task2.setEndDate(enddate2);
		task2.setParentTask(pt);
		task2.setIsCompleted(true);
		task2.setPriority(10);
		task2.setTask("Task_2");
		task2.setTaskId(2);
		task2.setProject(project);
		task2.setUser(user);

	}

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
