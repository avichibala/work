export class ParentTask {
    id: number;
    parentTaskName: string;
}