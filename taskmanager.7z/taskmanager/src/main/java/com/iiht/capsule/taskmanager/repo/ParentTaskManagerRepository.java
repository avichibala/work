package com.iiht.capsule.taskmanager.repo;

import org.springframework.data.repository.CrudRepository;

import com.iiht.capsule.taskmanager.model.ParentTask;

public interface ParentTaskManagerRepository extends CrudRepository<ParentTask, String> {

}
