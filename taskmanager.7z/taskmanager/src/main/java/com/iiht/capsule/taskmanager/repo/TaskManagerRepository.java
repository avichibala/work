package com.iiht.capsule.taskmanager.repo;

import org.springframework.data.repository.CrudRepository;

import com.iiht.capsule.taskmanager.model.Task;

public interface TaskManagerRepository extends CrudRepository<Task, String> {

}