import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Course } from "../models/course.model";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};

@Injectable()
export class CourseService {
  constructor(private http: HttpClient) {}

  private courseUrl = "http://localhost:8080/api/v1.0/lms/courses/";

  //private userUrl = '/api';

  public getCourse() {
    return this.http.get<Course[]>(this.courseUrl + "getall");
  }

  public getCourseByDuration(technology, durationFrom, durationTo) {
    return this.http.get<Course[]>(this.courseUrl + "get/"+technology+"/"+durationFrom+"/"+durationTo);
  }

  public getCourseByTechnology(technology) {
    return this.http.get<Course[]>(this.courseUrl + "info/"+technology);
  }

}
