package com.iiht.capsule.projectmanager.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.capsule.projectmanager.model.Task;
import com.iiht.capsule.projectmanager.repo.TaskRepository;

@Service
public class TaskServiceImpl implements TaskService {

	@Autowired
	private TaskRepository taskManagerRepository;

	@Override
	public Task addTask(Task task) {
		return taskManagerRepository.save(task);
	}

	@Override
	public List<Task> getAllTasks() {
		List<Task> tasks = new ArrayList<>();
		taskManagerRepository.findAll().forEach(tasks::add);
		return tasks;
	}

	@Override
	public Task updateTask(Task task, Long Id) {
		Task taskAvailable = taskManagerRepository.findById(Id).orElse(null);
		task.setTaskId(Id);
		taskManagerRepository.save(task);
		return taskAvailable;
	}

	@Override
	public Task getTask(Long Id) {
		Task taskAvailable = taskManagerRepository.findById(Id).orElse(null);
		return taskAvailable;
	}

	@Override
	public void deleteTask(Long Id) {

		taskManagerRepository.deleteById(Id);

	}

}
