package com.iiht.capsule.lms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.capsule.lms.entity.User;
import com.iiht.capsule.lms.model.UserRequest;
import com.iiht.capsule.lms.service.UserService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1.0/lms/company")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/register")
	public ResponseEntity<Object> addUser(@Valid @RequestBody UserRequest userRequest) {

		User createdUser = userService.addUser(userRequest);
		return ResponseEntity.status(HttpStatus.CREATED).body("User created with ID " + createdUser.getId());
	}

}