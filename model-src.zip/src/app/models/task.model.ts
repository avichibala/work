import { ParentTask } from "src/app/user/user";
import { Project } from "src/app/user/user";
import { Task } from "src/app/user/user";

export class Task {
    taskId: number;
    task: string;
    priority: number;
    parentTask: ParentTask;
	user: User;
	project: Project;
	priority: number;
	numberOfTasks: number;
	suspended: boolean;
	startDate: Date;
endDate: Date;
}
