package com.iiht.capsule.taskmanager.controller;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.iiht.capsule.taskmanager.model.Task;
import com.iiht.capsule.taskmanager.service.TaskManagerService;

@RestController
public class TaskManagerController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TaskManagerController.class);

	@Autowired
	private TaskManagerService taskManagerService;

	@RequestMapping("/hello")
	public String Tasks() {
		return "Hello";
	}

	@RequestMapping("/tasks")
	public List<Task> getAllTopics() {
		return taskManagerService.getAllTasks();
	}

	@PostMapping("/tasks")
	public ResponseEntity<Object> createTask(@RequestBody Task task) {
		LOGGER.info("********************" + task.toString());
		Task createdTask = taskManagerService.addTask(task);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(createdTask.getId()).toUri();

		return ResponseEntity.created(location).build();

	}

}
