package com.iiht.capsule.projectmanager.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ParentTask {

	@Id
	@GeneratedValue
	private long id;

	private String parentTaskName;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getParentTaskName() {
		return parentTaskName;
	}

	public void setParentTaskName(String parentTaskName) {
		this.parentTaskName = parentTaskName;
	}

	@Override
	public String toString() {
		return "ParentTask [id=" + id + ", parentTaskName=" + parentTaskName + "]";
	}

}
