import { Component } from "@angular/core";
import { User } from "./models/user.model";
import { taskDataService } from "./service/datastorage.service";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent {
  title = "app";
  userData: User;

  constructor(private dataStore: taskDataService) {
    this.userData = new User();
    this.dataStore.setUserData(this.userData);
  }


}
