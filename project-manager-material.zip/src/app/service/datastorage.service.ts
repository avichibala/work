import { Injectable } from "@angular/core";
import { User } from "../models/user.model";

@Injectable()
export class taskDataService {
  userData: User;
  getUserData() {
    return this.userData;
  }
  setUserData(data: User) {
    this.userData = data;
  }
}
