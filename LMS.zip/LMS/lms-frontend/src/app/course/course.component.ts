import { Component, HostListener, OnInit, ViewChild } from "@angular/core";
import { MdbTableDirective } from "angular-bootstrap-md";
import { NotificationService } from "../service/notification.service";
import { Course } from "../models/course.model";
import { CourseService } from "../service/course.service";
@Component({
  selector: "app-course",
  templateUrl: "./course.component.html",
  styleUrls: ["./course.component.scss"],
})
export class CourseComponent implements OnInit {
  courses: Course[] = [];
  course: Course;
  length = 0;

  @ViewChild(MdbTableDirective) mdbTable: MdbTableDirective;
  elements: any = [];
  headElements = ["name", "duration", "description", "technology"];

  searchText: string = "";
  technologyText: string = "";
  durationFromText: string = "";
  durationToText: string = "";
  previous: string;
  isDisabled: true;

  constructor(
    private notifyService: NotificationService,
    private courseService: CourseService
  ) {}

  @HostListener("input") oninput() {
    this.searchItems();
  }

  ngOnInit() {
    this.courseService.getCourse().subscribe(
      (data) => {
        this.showToaster("Courses retreived");
        data.forEach((entry) => {
          this.elements.push(entry);
        });
      },
      (err) => {
        this.notifyService.showWarning("Service is down", "Info");
        console.log(err);
      }
    );

    this.mdbTable.setDataSource(this.elements);
    this.elements = this.mdbTable.getDataSource();
    this.previous = this.mdbTable.getDataSource();
  }

  searchItems() {
    const prev = this.mdbTable.getDataSource();

    if (!this.searchText) {
      this.mdbTable.setDataSource(this.previous);
      this.elements = this.mdbTable.getDataSource();
    }

    if (this.searchText) {
      this.elements = this.mdbTable.searchLocalDataBy(this.searchText);
      this.mdbTable.setDataSource(prev);
    }
  }
  showToaster(message) {
    this.notifyService.showSuccess(message, "Info");
  }

  launchUrl(course: Course): void {
    window.open(course.launchUrl, "_blank");
  }

  searchCourse() {
    console.log(this.technologyText);
    console.log(this.durationFromText);
    console.log(this.durationToText);

    if (
      this.technologyText != "" &&
      this.durationFromText != "" &&
      this.durationToText != ""
    ) {
      this.elements = [];
      this.courseService
        .getCourseByDuration(
          this.technologyText,
          this.durationFromText,
          this.durationToText
        )
        .subscribe(
          (data) => {
            this.showToaster("Courses retreived for duration");
            data.forEach((entry) => {
              this.elements.push(entry);
            });
          },
          (err) => {
            this.notifyService.showWarning("Service is down", "Info");
            console.log(err);
          }
        );
    } else if (
      this.technologyText != "" &&
      this.durationFromText == "" &&
      this.durationToText == ""
    ) {
      this.elements = [];
      this.courseService.getCourseByTechnology(this.technologyText).subscribe(
        (data) => {
          this.showToaster("Courses retreived for technology");
          data.forEach((entry) => {
            this.elements.push(entry);
          });
        },
        (err) => console.log(err)
      );
    } else {
      this.elements = [];
      this.courseService.getCourse().subscribe((data) => {
        this.showToaster("Courses retreived");
        data.forEach((entry) => {
          this.elements.push(entry);
        });
      });
    }
    this.mdbTable.setDataSource(this.elements);
    this.elements = this.mdbTable.getDataSource();
    this.previous = this.mdbTable.getDataSource();
  }
}
