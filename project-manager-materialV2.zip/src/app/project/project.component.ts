import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ProjectService } from "../service/project.service";
import { UserService } from "../service/user.service";
import { Project } from "../models/project.model";
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ModalDirective } from "angular-bootstrap-md";
import { DatePipe } from '@angular/common';
import { User } from "../models/user.model";
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent implements OnInit {
  @ViewChild('closeBtn') closeBtn: ElementRef;
  @ViewChild('frame') frame: ModalDirective;
  projectForm: FormGroup;
  data;
  filterData;
  userData;
  isSubmitDisabled = false;
  isUpdateDisabled = true;
  title = "Add";
  constructor(
    private http: HttpClient,
    private projectService: ProjectService,
    private userService: UserService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe) {
    this.projectForm = this.createFormGroup(formBuilder);
  }

  createFormGroup(formBuilder: FormBuilder) {
    return formBuilder.group({
      projectName: '',
      startDate: '',
      endDate: '',
      priority: '',
      manager: formBuilder.group({
        userId: ''
      })
    });
  }

  ngOnInit() {
    this.getData();
    this.getUserData();
  }

  onUserChange(user: User) {
    console.log(user);
  }
  addProjectData() {
    this.projectForm = this.createFormGroup(this.formBuilder);
    this.isSubmitDisabled = false;
    this.isUpdateDisabled = true;
    this.title = "Add";
  }

  updateProjectData(project: Project) {
    this.projectForm = this.createEditFormGroup(this.formBuilder, project);
    this.isSubmitDisabled = true;
    this.isUpdateDisabled = false;
    this.title = "Update";
  }

  createEditFormGroup(formBuilder: FormBuilder, project: Project) {
    return formBuilder.group({
      projectId: project.projectId,
      projectName: project.projectName,
      startDate: project.startDate,
      endDate: project.endDate,
      priority: project.priority,
      manager: formBuilder.group({
        userId: project.manager.userId
      })
    });
  }

  revert() {
    // Resets to blank object
    // Resets to provided model

    if (this.title == "Add") { this.projectForm = this.createFormGroup(this.formBuilder); }
    else {
      this.projectForm.patchValue({
        projectName: '',
        startDate: '',
        endDate: '',
        priority: '',
        manager: ({
          userId: ''
        })
      });
    }
  }

  getData(): void {
    this.projectService.getProject().subscribe(res => {
      this.data = res;
      this.filterData = res;
    },
      err => { console.log("Error occured"); }
    );

    console.log("Get Data" + JSON.stringify(this.filterData));
  }


  getUserData(): void {
    this.userService.getUser().subscribe(res => {
      this.userData = res;
    },
      err => { console.log("Error occured"); }
    );

    console.log("Get Data" + JSON.stringify(this.userData));
  }

  getFormatdate(changeDate: Date): any {
    return this.datePipe.transform(changeDate, "yyyy-MM-dd");
  }

  updateProject() {
    const project: Project = Object.assign({}, this.projectForm.value);

    // Do useful stuff with the gathered data
    console.log("Update Project");
    console.log(project);
    this.projectService.updateProject(project).subscribe(data => {
      this.getData();
    });
    this.frame.hide();
  }


  deleteProject(project: Project): void {
    this.projectService.deleteProject(project).subscribe(

      data => {
        this.getData();
      }
    );
  }

  onSubmit() {
    // Make sure to create a deep copy of the form-model
    const project: Project = Object.assign({}, this.projectForm.value);

    var startDate = this.getFormatdate(project.startDate);
    var enddate = this.getFormatdate(project.endDate);
    console.log(startDate);
    console.log(enddate);
    this.projectForm.patchValue({
      startDate: startDate,
      endDate: enddate
    });

    const projectData: Project = Object.assign({}, this.projectForm.value);
    // Do useful stuff with the gathered data
    console.log(projectData);

    this.projectService.createProject(projectData).subscribe(data => {
      console.log(projectData);
      this.ngOnInit();
    });
    this.closeBtn.nativeElement.click();
    this.frame.hide();


  }

  changeValue(rangevalue: any) {
    console.log(rangevalue);
    this.projectForm.patchValue({
      priority: rangevalue
    });
  }

  search(term: string) {
    if (!term) {
      this.filterData = this.data;
      console.log("Filter Data before Search" + JSON.stringify(this.filterData));
    } else {
      this.filterData = this.data.filter(
        x =>
          x.projectName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.numberofTasks.toString()
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.completedTasks.toString()
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.manager.firstName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.manager.lastName
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.startDate
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.endDate
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase()) ||
          x.priority.toString()
            .trim()
            .toLowerCase()
            .includes(term.trim().toLowerCase())
      );
      console.log("Filter Data after Search" + JSON.stringify(this.filterData));
    }
  }





}
