import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppComponent } from "./app.component";
import { UserService } from "./service/user.service";
import { ProjectService } from "./service/project.service";
import { TaskService } from "./service/task.service";
import { AppRoutingModule } from "./app.routing.module";
import { MDBBootstrapModule } from "angular-bootstrap-md";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { UserComponent } from "./user/user.component";
import { ProjectComponent } from "./project/project.component";
import { NavigationComponent } from "./navigation/navigation.component";
import { DataTableModule } from "angular-6-datatable";
import { HttpClientModule } from "@angular/common/http";
import { DatePickerModule } from "@syncfusion/ej2-angular-calendars";
import { taskDataService } from "./service/datastorage.service";
import { DatePipe } from '@angular/common';
import { NgxBootstrapSliderModule } from 'ngx-bootstrap-slider';
@NgModule({
  declarations: [AppComponent, UserComponent, NavigationComponent, ProjectComponent],
  imports: [
    BrowserModule,
    DatePickerModule,
    DataTableModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxBootstrapSliderModule
  ],
  providers: [UserService, taskDataService, ProjectService, TaskService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
